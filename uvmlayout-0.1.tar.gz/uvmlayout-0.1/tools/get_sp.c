#include <stdio.h>

/*

   |  ....     |
   |-----------| old ebp
   |           |
   |           |
   |           |
   |-----------| old esp
   |  old eip  |
   |-----------|
   |  old ebp  |
   |-----------| ebp
   |           |
   |           |
   |           |
   |           |
   |-----------| esp
   |           |

*/


void *
get_sp(void *old_sp)
{
        void *fpp = NULL; 

	if (old_sp) {
#if defined(__i386__)
        asm volatile ("mov 0x0(%1), %0" : "=r" (fpp) : "r" (old_sp) );
#elif defined(__x86_64__)
        asm volatile ("mov 0x0(%1), %0" : "=r" (fpp) : "r" (old_sp) );
#endif
	} else {
#if defined(__i386__)
        asm volatile ("mov %%ebp, %0" : "=r" (fpp));
#elif defined(__x86_64__)
        asm volatile ("mov %%rbp, %0" : "=r" (fpp));
#endif
	}

#if defined(DEBUG)
        printf("EBP = %p\n", fpp);
#endif

        return fpp;
}

#if defined(SINGLE)
main()
{
	void *sp = NULL;

	do {
		sp = get_sp(sp);
		printf("sp = %p\n", sp);
	} while (sp);
}
#endif
