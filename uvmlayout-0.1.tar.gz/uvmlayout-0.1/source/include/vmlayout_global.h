#ifndef VMLAYOUT_GLOBAL_H__
#define VMLAYOUT_GLOBAL_H__

#include <vmlayout_support.h>
#include <vmlayout_elfconst.h>
#include <vmlayout_list.h>

#endif /* ! VMLAYOUT_GLOBAL_H__ */
