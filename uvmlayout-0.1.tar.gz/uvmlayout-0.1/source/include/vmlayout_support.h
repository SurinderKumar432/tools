#ifndef VMLAYOUT_SUPPORT_H__
#define VMLAYOUT_SUPPORT_H__

#if !(defined(__i386__) || defined(__x86_64__))
#error "Unsupported platform."
#endif

#endif /* ! VMLAYOUT_SUPPORT_H__ */
